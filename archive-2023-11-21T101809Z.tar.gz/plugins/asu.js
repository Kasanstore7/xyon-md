let handler = async (m, { conn, text, usedPrefix, command }) => {
let fetch = require("node-fetch")
let tio = 'ʜᴀʏᴏ ʙᴀɴɢ ɢᴀʙᴏʟᴇʜ ɢɪᴛᴜ'
 await conn.sendFile(
    m.chat,
    "https://aemt.me/file/7C6jiHBa84Ss.opus",
    "7C6jiHBa84Ss.opus",
    null,
    m,
    true,
    {
      type: "audioMessage",
      ptt: false,
      seconds: 90000,
      contextInfo: {
        forwardingScore: fsizedoc,
        externalAdReply: {
          body: null,
          containsAutoReply: true,
          mediaType: 1,
          mediaUrl: sig,
          renderLargerThumbnail: true,
          showAdAttribution: true,
          sourceId: null,
          sourceType: "PDF",
          previewType: "PDF",
          sourceUrl: gcbot,
          thumbnailUrl:
            "https://telegra.ph/file/7c71907225f33f3ba5eb6.jpg",
          title: "🗿"
        }
      }
    }
  );
};

handler.customPrefix = /^(crot|ahah|ah|crit|anjir|sange|prot|Xia|cortttt|anjing|lonte|kontol|memek)$/i
handler.command = new RegExp

module.exports = handler