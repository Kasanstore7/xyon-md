global.fsw = { "key": { "remoteJid": "", "participant":"0@s.whatsapp.net", "fromMe": false, "id": "" },
	"message": { "conversation": "SaxiaBotzMd" }}