var fs = require('fs')
var fetch = require('node-fetch');
var util = require('util');
var handler = async (m, {
 text, 
 usedPrefix, 
 command
 }) => {
if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia? `
await m.reply(wait)
  await conn.groupLeave(text) //will throw error if it fails)
} catch (err) {
m.reply(util.format(js))
}}
handler.command = handler.help = ['keluar'];
handler.tags = ['info'];
handler.limit = 3
module.exports = handler;