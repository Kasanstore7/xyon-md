const fs = require('fs');
const fetch = require('node-fetch');
const util = require('util');

const handler = async (m, { text, usedPrefix, command }) => {
  const wm = 'apalah';

  const ftex = {
    key: {
      fromMe: false,
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      "extendedTextMessage": {
        "text": 'Quotes Islami',
        "title": 'Quotes Islam',
        "jpegThumbnail": fs.readFileSync('./thumbnail.jpg', { encoding: 'base64' })
      }
    }
  };

  try {
    const lolhumanAPIKey = 'GataDios';
    const response = await fetch(`https://api.lolhuman.xyz/api/quotes/islami?apikey=${lolhumanAPIKey}`);
    const json = await response.json();
    await conn.reply(m.chat, json.result, ftex);
  } catch (err) {
    console.log(err);
  }
};

handler.command = handler.help = ['qislami', 'quotesislam', 'quotesislami'];
handler.tags = ['quotes', 'internet'];
handler.limit = true;

module.exports = handler;