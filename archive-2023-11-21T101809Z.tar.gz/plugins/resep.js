const axios = require('axios');

async function searchRecipe(text) {
  try {
    const response = await axios.get(`https://aemt.me/caribacaresep?query=${text}`);
    return response.data;
  } catch (error) {
    console.error('Error searching for recipes:', error.message);
    throw error;
  }
}

module.exports = { searchRecipe };