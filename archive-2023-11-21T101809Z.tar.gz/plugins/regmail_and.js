const similarity = require('string-similarity');
const threshold = 0.72;

const before = async function before(m) {
  let id = m.chat;
  
  if (
    !m.quoted ||
    !m.quoted.fromMe ||
    !m.quoted.isBaileys ||
    !m.text ||
    !/Ketik.*hotp/i.test(m.quoted.text) ||
    /.*hotp/i.test(m.text)
  ) {
    return true;
  }
  
  this.regmail = this.regmail ? this.regmail : {};
  
  if (!(id in this.regmail)) {
    return this.reply(m.chat, '*❗ Kode verifikasi Anda telah kedaluwarsa.*', m);
  }
  
  if (m.quoted.id == this.regmail[id][0].id) {
    let isSurrender = /^(cancel|batal)$/i.test(m.text);
    
    if (isSurrender) {
      clearTimeout(this.regmail[id][3]);
      delete this.regmail[id];
      return this.reply(m.chat, '*❌ Nomor Anda tidak berhasil diverifikasi.*', m);
    }
    
    let json = JSON.parse(JSON.stringify(this.regmail[id][1]));
    // this.reply(JSON.stringify(json, null, '\t'));
    
    if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
      global.db.data.users[m.sender].exp = this.regmail[id][2];
      this.reply(m.chat, `*✅ Nomor Anda telah berhasil diverifikasi.*\n ${this.regmail[id][2]} XP`, m);
      clearTimeout(this.regmail[id][3]);
      delete this.regmail[id];
    } else if (similarity.compareTwoStrings(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
      this.reply(m.chat, `*❗ Sedikit Lagi!*`);
    } else {
      this.reply(m.chat, `*❌ Kode verifikasi Anda salah.*`, m);
    }
  }
  
  return true;
}

module.exports = {
  before,
  buttonregmail: [['regmail', '/regmail']]
};