const { color } = require('../lib/color');
const moment = require("moment-timezone");
let levelling = require('../lib/levelling');

module.exports = {
  before: async (m, conn) => {
    let pp = './src/avatar_contact.png';
    try {
      pp = await conn.getProfilePicture(m.sender);
    } catch (error) {
      console.log(error);
    }
    
    let user = global.db.data.users[m.sender];
    if (!user.autolevelup) return true;
    
    let before = user.level * 1;
    while (levelling.canLevelUp(user.level, user.exp, global.multiplier)) {
      user.level++;
    }
    
    if (before !== user.level) {
      let chating = `Selamat Level Anda naik ke! *${before}* -> *${user.level}*\nKetik *.profile* untuk cek`.trim();
      conn.sendMessage(m.chat, {
        text: chating,
        contextInfo: {
          externalAdReply: {
            title: "",
            body: '',
            thumbnailUrl: pp,
            sourceUrl: "",
            mediaType: 1,
            renderLargerThumbnail: true
          }
        }
      }, { quoted: m });
      console.log(color(chating, 'pink'));
    }
  }
};