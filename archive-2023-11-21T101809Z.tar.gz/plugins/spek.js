const fetch = require('node-fetch')

if (!text) throw `Contoh penggunaan ${usedPrefix}${command} oppo`

let res = await fetch(`https://api.lolhuman.xyz/api/gsmarena?apikey=GataDios&query=${text}`)
  let sul = await res.json()
  let has = sul.result
  await conn.reply(m.chat, `*Name:* ${has.phone_name}
  *Speed:* ${has.specification.network.speed}
  *Launch:* ${has.specification.launch.status}
  *Body:* ${has.specification.body.build}
  *Dis status:* ${has.specification.display.displaytype}
  *Plat:* ${has.specification.platform.os}
  ${has.specification.platform.chipset}
  ${has.specification.platform.cpu}
  *Mem:* ${has.specification.memory.internalmemory}
  *Batre:* ${has.specification.battery.batdescription1}
`, author, has.phone_image, m)
}
handler.tags = ['internet']
handler.help = ['spek']
handler.command = ['spek', 'tes2']
module.exports = handler