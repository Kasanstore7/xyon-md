var fs = require('fs')
var fetch = require('node-fetch');
var util = require('util');
var handler = async (m, {
 text, 
 usedPrefix, 
 command
 }) => {
if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia? `
await m.reply(wait)
  var ftex = {
            key: { 
                 fromMe: false,
                 remoteJid: 'status@broadcast',
    participant : '0@s.whatsapp.net'
    },
            message: { 
               "extendedTextMessage": {
                        "text": 'By Xyon',
                        "title": 'NAMA KARAKTER : ELAINA',
                        'jpegThumbnail': fs.readFileSync('./thumbnail.jpg')
                               }
                             } 
                            }
  var js = await fetch(`https://api.botcahx.live/api/search/c-ai?prompt=${text}&char=Elaina&apikey=${kasan}`)
var json = await js.json()
try {
  await conn.reply (m.chat, json.message, m)
} catch (err) {
m.reply(util.format(js))
}}
handler.command = handler.help = ['cai','characterai','celaina'];
handler.tags = ['info'];
handler.limit = 3
module.exports = handler;