let handler = async (m, { conn, usedPrefix }) => {
  conn.reply(m.chat, `
╭─˗ˏˋ *INFORMASI OWNER* ´ˎ˗│
✎ _Nama_ : Kasan
✎ _Hobi_ : Makan
✎ _Umur_ : -
✎ _Asal_ : Jawa Tengah, Brebes
✎ _Status_ : Pemula
┗━━═┅═━━––––––––––✦

↬ _Group Official_ :
https://chat.whatsapp.com/GeWPLmclHaVHsF0GymCcJz

↬ _Chanel Whatsapp_ :
https://whatsapp.com/channel/0029Va9CvIaLdQehC1yCG11O

❖––––『 Sosial Media 』––––❖

𖤍 _Instagram_ : instagram.com/sxa_ksndn
𖤍 _WhatsApp_ : https://wa.me/4915147222100
𖤍 _Website_ : https://kasan.biz.id

╰───────────────────๑
`.trim(), m);
}

handler.help = ['infokasan'];
handler.tags = ['main', 'utama'];
handler.command = /^(infokasan)$/i;
handler.limit = 1;

module.exports = handler;