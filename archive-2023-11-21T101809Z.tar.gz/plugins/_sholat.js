const fetch = require('node-fetch')
const { generateWAMessageFromContent } = require("@adiwajshing/baileys")

let handler = m => m

handler.before = async function (m) {
  if (!m.message)
    return

  let waktuSholat = {
    imsak: '04:22',
    subuh: '04:39',
    terbit: '06:04',
    dhuha: '06:31',
    dzuhur: '12:02',
    ashar: '15:10',
    maghrib: '18:03',
    isya: '19:12'
  }

  /* Waktu Sekarang */
  let _ = new Date((new Date).toLocaleString("en-US", {
    timeZone: "Asia/Jakarta"
  }))
  let jam = _.getHours()
  let menit = _.getMinutes()
  let formatJam = jam < 10 ? '0' + jam : jam
  let formatMenit = menit < 10 ? '0' + menit : menit
  let waktuSekarang = formatJam + ':' + formatMenit

  /* Opsi */
  let logo_ = "https://flamingtext.com/net-fu/proxy_form.cgi?"
  let teks_
  
  if (waktuSekarang == waktuSholat.imsak) {
    teks_ = "Daerah *Jakarta* sudah waktunya *Imsak!*"
  } else if (waktuSekarang == waktuSholat.subuh) {
    teks_ = "Daerah *Jakarta* sudah waktunya *sholat Subuh!*"
  } else if (waktuSekarang == waktuSholat.terbit) {
    teks_ = "Daerah *Jakarta* sudah waktunya *Terbit!*"
  } else if (waktuSekarang == waktuSholat.dhuha) {
    teks_ = "Daerah *Jakarta* sudah waktunya *sholat Dhuha!*"
  } else if (waktuSekarang == waktuSholat.dzuhur) {
    teks_ = "Daerah *Jakarta* sudah waktunya *sholat Dzuhur!*"
  } else if (waktuSekarang == waktuSholat.ashar) {
    teks_ = "Daerah *Jakarta* sudah waktunya *sholat Ashar!*"
  } else if (waktuSekarang == waktuSholat.maghrib) {
    teks_ = "Daerah *Jakarta* sudah waktunya *sholat Maghrib!*"
  } else if (waktuSekarang == waktuSholat.isya) {
    teks_ = "Daerah *Jakarta* sudah waktunya *sholat Isya!*"
  }

  if (teks_) {
    let icon = await (await fetch(logo_ + teks_.split(" ").pop().replace(/\*/g, ""))).buffer()
    let msg = await generateWAMessageFromContent(m.chat, {
      extendedTextMessage: {
        text: teks_,
        jpegThumbnail: icon,
        contextInfo: {
          mentionedJid: [m.sender],
          externalAdReply: {
            title: 'A Y O !',
            body: 'S H O L A T',
            thumbnail: icon,
            mediaType: 1,
            sourceUrl: null
          }
        }
      }
    }, { quoted: m })
    await this.relayMessage(m.chat, msg.message, {})
  }
}

/*by Hikosova*/
/*modal copy paste ngaku² buatan sendiri*/