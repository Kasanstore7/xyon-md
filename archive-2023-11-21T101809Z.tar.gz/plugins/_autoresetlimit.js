async function before(m) {
  if (m.isBaileys || !m.sender || !m.text) return;
		let __timers = (new Date - global.db.data.lastclaim)
		let _timers = (86400000 - __timers)
		let timers = clockString(_timers) 
		let time = global.db.data.lastclaim + 86400000;
		let anu = global.db.data
		if (new Date - anu.lastclaim > 86400000) {
			let list = Object.entries(global.db.data.users)
			let lim = 350
			list.map(([user, data], i) => (data.limit = lim))
					anu.lastclaim = new Date * 1
		} else return
  }
  
const disabled = false;

module.exports = {
  before,
  disabled
};

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  console.log({ms,h,m,s})
  return [h, m, s].map(v => v.toString().padStart(2, 0) ).join(':')
}

function msToTime(duration) {
    const milliseconds = parseInt((duration % 1000) / 100);
    let seconds = Math.floor((duration / 1000) % 60);
    let minutes = Math.floor((duration / (1000 * 60)) % 60);
    let hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

    hours = (hours < 10) ? "0" + hours : hours;
    minutes = (minutes < 10) ? "0" + minutes : minutes;
    seconds = (seconds < 10) ? "0" + seconds : seconds;

    return hours + " Jam " + minutes + " Menit " + seconds + " Detik";
}