global.sewabot = `–  *S E W A - B O T*
   
  ➠ Sewa 
    ┌  ◦  5k / 7 Hari
    │  ◦  10k / 15 Hari
    │  ◦  15k / 30 Hari
    └  ◦  30k / 60 Hari
  Bot masuk ke grup Kamu
    
  ➠ Premium
    ┌  ◦  10k / 30 Hari
    └  ◦  20k / 60 Hari
  Untuk mendapatkan fitur khusus Premium
  
  ➠ Pembayaran
    ┌  ◦  Pulsa : -/ belum tersedia 
    └  ◦  Dana : -/ belum tersedia 
  Jika Berminat Hubungi > @${global.owner[0]}`,