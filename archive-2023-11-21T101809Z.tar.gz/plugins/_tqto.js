global.tqto = `🛠️ *Terimakasih Kepada Seluruh Team/Crew/Creator yang bersangkutan Kepada Pembuatan Script Saxia-Md* 🛠️

• Tio ( Rtxzy-Md )
• Mark - Hadr (Kurukuu-Md)
• Nayla ( Nayla Bot)
• Marxel (Saxia-Bot)
• Kasan [ PEMBUAT SCRIPT ]
• Ridwan ( Aiine-Md  )

belikan saia rokok dengan mengetik .donasi :v`