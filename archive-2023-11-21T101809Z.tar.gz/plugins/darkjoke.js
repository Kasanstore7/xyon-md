const fetch = require('node-fetch');

async function handler(m) {
  const response = await fetch(`https://api.lolhuman.xyz/api/meme/darkjoke?apikey=GataDios`)
  const json = await response.json();
  const mediaUrl = json.result;

  // Mengirim media sebagai GIF
  await m.reply(m.chat, mediaUrl, 'fgif', { adReply: true });
}

handler.command = handler.help = ['darkjoke'];
handler.tags = ['internet'];
module.exports = handler;