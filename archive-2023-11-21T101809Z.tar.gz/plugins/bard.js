const fs = require('fs');
const fetch = require('node-fetch');
const util = require('util');

const handler = async (m, { text, usedPrefix, command, conn }) => {
  if (!text) throw 'Masukkan pertanyaan!\n\n*Contoh:* .bard Siapa itu Jokowi Dodo';
  
  await m.reply('Mohon tunggu...');

  const ftex = {
    key: {
      fromMe: false,
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      extendedTextMessage: {
        text: 'Module Chat GPT-4',
        title: 'Ai Bard By Xyon',
        jpegThumbnail: fs.readFileSync('./thumbnail.jpg')
      }
    }
  };

  try {
    const response = await fetch(`https://api.betabotz.org/api/search/bard-ai?apikey=${kasan}&text=${text}`).then(res => res.json());
    await conn.reply(m.chat, response.message, m);
  } catch (err) {
    m.reply(util.format(err));
  }
};

handler.command = handler.help = ['bard', 'aibard', 'googlebard'];
handler.tags = ['info'];
handler.premium = true

module.exports = handler;