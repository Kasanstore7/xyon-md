global trol = {
		key: {
			fromMe: false,
			fromMe: false,
			participant: `0@s.whatsapp.net`,
			...({
				remoteJid: ""
			})
		},
		"message": {
			"orderMessage": {
				"orderId": "594071395007984",
				"thumbnail": await (await fetch(pp)).buffer(),
				"itemCount": 100000000000,
				"status": "INQUIRY",
				"surface": "CATALOG",
				"message": "",
				"orderTitle": '👋 ' + sapa + ' Kak :> ' + name,
				"sellerJid": "62857887347569@s.whatsapp.net",
				"token": "AR40+xXRlWKpdJ2ILEqtgoUFd45C8rc1CMYdYG/R2KXrSg==",
				"totalAmount1000": "500000000000000",
				"totalCurrencyCode": "IDR"
			}
		}
	}