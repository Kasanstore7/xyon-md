let handler = async m => {
m.reply('Langsung Chat @4915147222100');
}
handler.command = /^(sewabot|sewa|belibot)$/i
handler.tags = ['main']
handler.limit = true

module.exports = handler