global.fp = {
    "key": {
        "remoteJid": "0@s.whatsapp.net",
        "fromMe": False,
        "id": "BAE595C600522C9C",
        "participant": "0@s.whatsapp.net"
    },
    "message": {
        "requestPaymentMessage": {
            "currencyCodeIso4217": "wm",
            "amount1000": 99999,
            "requestFrom": "0@s.whatsapp.net",
            "noteMessage": {
                "extendedTextMessage": {
                    "text": "Hai Kak " + m.name
                }
            },
            "expiryTimestamp": 999999,
            "amount": {
                "value": 999,
                "offset": 9999,
                "currencyCode": "wm"
            }
        }
    }
}