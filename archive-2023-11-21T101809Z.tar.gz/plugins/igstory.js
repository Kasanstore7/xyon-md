const fetch = require("node-fetch")
const util = require("util")

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (args.length == 0) throw `Gunakan contoh ${usedPrefix}${command} Alafasy`
    
    m.reply('Tunggu sebentar...')
    
    const text = args.join(" ")
    const url = encodeURI(`https://api.lolhuman.xyz/api/igstory/${text}?apikey=GataDios`)
    
    try {
        let response = await fetch(url)
        let data = await response.json()
        
        if (!data.message) throw data
        if (data.message === "API Limit Reached") throw 'Limit penggunaan API telah habis'
        
        for (let result of data.message) {
            conn.sendFile(m.chat, result.result, null, '*Instagram Story*', m)
        }
    } catch (err) {
        console.log(err)
        m.reply(util.format(err))
    }
}

handler.help = ['igs <username>']
handler.tags = ['downloader']
handler.command = /^(igs|igstory)$/i
handler.limit = true

module.exports = handler