let handler = async (m) = {
m.reply('Halo, ada yang bisa saya bantu?')
{
handler.customPrefix = /^(bot|bot?|bott)$/i
handler.command = new RegExp

module.exports = handler