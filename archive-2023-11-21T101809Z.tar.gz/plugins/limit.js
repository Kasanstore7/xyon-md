let handler = async (m) => {
    let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
    else who = m.sender
    if (typeof db.data.users[who] == 'undefined') throw 'Pengguna tidak ada didalam data base'
    m.reply(`⌛Sisa Limit Anda : ${global.db.data.users[who].limit} Reset Limit Setiap 24Jam. , Beli Premium Agar Limit Unlimited`)
}
handler.help = ['limit <@user>']
handler.tags = ['xp']
handler.command = /^(limit)$/i
module.exports = handler