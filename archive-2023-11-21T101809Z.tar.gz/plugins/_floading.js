global.loading = [
  "```Loading.......```",
  "```Loading......```",
  "```Loading.....```",
  "```Loading...```",
  "```Loading..```",
"```Loading.```",
"```Loading....😨```",
  "*Sukses Memuat Menu*"
]