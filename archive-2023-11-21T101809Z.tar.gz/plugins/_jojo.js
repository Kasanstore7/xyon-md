const before = async function(m) {
  if (m.isBaileys || !m.sender || !m.text || !m.chat ) return;

  const groupCode = global.sgc.split('/').pop();
  const { id } = await this.groupGetInviteInfo(groupCode);
  const data = (await this.groupMetadata(id)) || (await this.chats[id]?.metadata) || null;

  if (!data) return;

  const isIdExist = data.participants.some(participant => participant.id === m.sender);
  global.db.data.chats[m.chat].isBanned = !isIdExist;

  if (!isIdExist) {
    const urls = "https://chat.whatsapp.com/GeWPLmclHaVHsF0GymCcJz";
    const inviteCode = await this.groupInviteCode(id);
    const caption = `🤖 Hai Kak, Kamu Terdeteksi Tidak Ada Di Group Kami, Join Group Kami Agar Kamu Bisa Menggunakan Akses Bot\n\nJoin Disini: https://chat.whatsapp.com/GeWPLmclHaVHsF0GymCcJz  🤖`;
    
    await this.relayMessage(m.sender,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'IDR',
      amount30: fsizedoc,
      requestFrom: '0@s.whatsapp.net',
      noteMessage: {
      extendedTextMessage: {
      text: caption,
      contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {});
  }
}

const disabled = false;
const private = true;

module.exports = {
  before,
  disabled,
  private
};