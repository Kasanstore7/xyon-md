let fs = require('fs');
let handler = async (m, { conn, args, command }) => {
  let tag = `@${m.sender.replace(/@. /, '')}`;
  const ftex = {
    key: {
      fromMe: false,
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      "extendedTextMessage": {
        "text": 'Hallo Kak 👋',
        "title": '',
        'jpegThumbnail': fs.readFileSync('./thumbnail.jpg')
      }
    }
  };
  conn.sendMessage(m.chat, {
    text: `Hai Kak ${tag} Ada Apa Manggil Nama Owner saya, Suka Ya????`,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        title: 'Kiw Kiw',
        body: '',
        thumbnailUrl: 'https://telegra.ph/file/61a251b8d485eaa30d6ca.jpg',
        mentionedJid: [tag],
        sourceUrl: gcbot,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, {
    quoted: m
  });
  conn.reply(m.chat, `Sayang ada yang nyariin kamu nih @${global.owner[0]}`);
};

handler.customPrefix = /^(?:.*\b(kasan|albert)\b.*)$/i;
handler.command = new RegExp(/^.*$/, 'i');
handler.limit = false;

module.exports = handler;