let fetch = require('node-fetch');
let handler = async (m, { text, conn }) => {
  if (!text) throw 'Masukkan text nya';

  let res = await fetch(`https://api.lolhuman.xyz/api/stalkig/${text}?apikey=GataDios`);
  let json = await res.json();
  let kasan = `Username: ${json.result.username}
Posts: ${json.result.post}
Followers: ${json.result.followers}`;

  await conn.sendFile(m.chat, json.result.photo_profile, 'photo_profile.jpg', `${kasan}`, null, { quoted: m });
};

handler.help = ['igstalk'];
handler.tags = ['internet', 'fun'];
handler.command = /^igstalk$/i;

module.exports = handler;