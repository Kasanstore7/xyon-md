const fetch = require('node-fetch');

if (!text) return reply(`*Masukan Query!*\n\n*Contoh :* ${prefix}gsmarena Samsung a01`);

const gsmarena = require('gsmarena-api');

reply(mess.wait);

try {
  let anu = await gsmarena.search.search(text);
  let res = anu[0];
  let res1 = await gsmarena.catalog.getDevice(res.id);
  let capt = `*GSM ARENA - DETAILS DEVICE*\n`;
  
  for (let i of res1.quickSpec) {
    capt += `*${i.name} :* ${i.value}\n`;
  }
  
  capt += `${readMore}`;
  
  for (let i of res1.detailSpec) {
    capt += `\n*${i.category} :*\n`;
    
    for (let data of i.specifications) {
      capt += `- ${data.name} ( ${data.value} )\n`;
    }
  }

  conn.sendFile(m.chat, res1.img, '', capt, m);
} catch (error) {
  reply(`*Not Found!*`);
}
handler.command ['spek'];
handler.premium = true

module.exports = handler