let fetch = require('node-fetch')

let handler = async (m, { conn, usedPrefix, command }) => {
let res = await fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/anime/neko.txt')
let txt = await res.text()

let arr = txt.split('\n')
let cita = arr[Math.floor(Math.random() * arr.length)]
let cap =`*乂 BIG THANKS TO*

*❉ BOTCHAX:*
https://github.com/BOTCAHX (base)
*❉ Lann:* 
https://github.com/ERLANRAHMAT
*❉ Mark:* https://github.com/kurukumd
*❉ Nayla:* 
https://github.com/Nayla-Hanifah 
*❉ Kasan:*
https://github.com/kasanstore7 (Recode)`
await conn.reply(m.chat, cap, m, { contextInfo: {
externalAdReply: {
            title: 'thanks for helping me',
            body: '',
            description: wm,
            mediaType: 1,
           thumbnailUrl: '',
         renderLargerThumbnail: true,
sourceUrl: gcbot,
        }
     }
    })
 }
handler.help = ['tqto']
handler.tags = ['info']
handler.command = /^(credits?|thanks?to|tqto|ttq)$/i

module.exports = handler