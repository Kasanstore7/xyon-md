let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(global.iman)}”`, m)
}
handler.help = ['imancek']
handler.tags = ['game']
handler.command = /^(imancek)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

global.iman = [
'Banyak iman : 4%\n\nBukan Orang beriman!',
'Banyak iman : 7%\n\nUdah ga ada kepercayaan!',
'Banyak iman : 12%\n\nSudah mulai hilang imannya',
'Banyak iman : 22%\n\nHampir hilang keimanan',
'Banyak iman : 27%\n\nMulai tidak beriman',
'Banyak iman : 35%\n\nMasih mencoba beriman',
'Banyak iman : 41%\n\nHanya sedikit imannya',
'Banyak iman : 48%\n\nSetengah imannya',
'Banyak iman : 56%\n\nMasih beriman',
'Banyak iman : 64%\n\nLumayan beriman',
'Banyak iman : 71%\n\nPasti Mulai hilang keimanan',
'Banyak iman : 1%\n\nSudah bukan manusia',
'Banyak iman : 77%\n\nMasih ada imannya',
'Banyak iman : 83%\n\nDijamin dia orang beriman',
'Banyak iman : 89%\n\nDia orang beriman, rajin ibadah!',
'Banyak iman : 94%\n\nRajin ibadah setiap saat',
'Banyak iman : 100%\n\nImannya kuat banget cuyy, Ibadah 24 Jam ini',
]