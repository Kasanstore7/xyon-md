// Created by Nayla
// Fixed by nzka


const fetch = require("node-fetch");

const handler = async (m, { conn, args, usedPrefix, command }) => {
  //if (!args[0]) throw `Masukkan URL!\n\nContoh:\n${usedPrefix + command} https://vm.tiktok.com/ZGJAmhSrp/`;
  //if (!args[0].match(/tiktok/gi)) throw `URL Tidak Ditemukan!`;
  m.reply("Tunggu sebentar...");  
		const url = `${m.text}`
		const apis = await fetch(API('kasan', '/api/dowloader/tiktok', { url: url, apikey: kasan }));
		if (!apis.ok) throw await apis.text()
var jsons = await apis.json()
if (!jsons.status) throw jsons
var { 
video, 
title,
title_audio,
audio
} = jsons.result
await conn.sendFile(m.chat, video, 'tiktok.mp4', `▢ *Title:* ${title}\n▢ *Deskripsi:* ${title_audio}`, m)
conn.sendFile(m.chat, `${audio[1]}`, 'tikmp3.opus', null, m)
};
handler.help = ['tiktok']
handler.customPrefix = /https:\/\/vm\.tiktok\.com\/[A-Za-z0-9]+/g;
handler.command = new RegExp
handler.limit = 2;
handler.group = false;

module.exports = handler;